
import Link from "next/link"

function Navbar() {
return(
    <ul className="flex justify-center items-center gap-4" >
   <li><Link href="/" className="bg-blue-400" >
          Home 
          </Link></li>
       
        <li><Link href="/pakistan" >
          Pakistan
          </Link></li>
        <li>
           <Link href="/world" >
           world 
          </Link>
        </li>
        
         </ul>
)
}


export default Navbar