
import Link from "next/link"

function Category () {
    return (
        <div>
          
        <ul className="text-blue-500 text-sm">
            <li> 
                <Link href="/pakistan">Pakistan</Link>
                </li>
            <li>
                <Link href="/world"> World</Link>
                </li>
            
        </ul>
        </div>
    )
}

export default Category