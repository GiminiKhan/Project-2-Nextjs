
function Pakistan() {
    return (
   <div>
    <h1>This Page is about Pakistan</h1>
    </div>
    ) }
    export default Pakistan